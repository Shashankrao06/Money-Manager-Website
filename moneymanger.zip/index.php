<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="i.css">
    <title>Document</title>
</head>
<body>
    <header>
        <div class="wrapper">
            <div class="logo">
                <h1>Money Manager</h1>
            </div>
            <ul class="nav-area">
                <li><a href="#">Home</a></li>
                <li><a href="signup.php">Sign up</a></li>
                <li><a href="login.php">Login</a></li>
                <!-- <li><a href="newlogin.php">Newlogin</a></li> -->
            </ul>
        </div>
        <div class="welcome_text">
            <h1>A website to manage your money details </h1>
        </div>
    </header>

</body>
</html>