function alertf(){
    alert("Details added successfully");
}