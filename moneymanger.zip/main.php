

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="iindex.css">
    <script src="main.js"></script>
    <title>Document</title>
</head>
<body>
    <div class="maindiv">
        <header>
    <div class="wrapper">
            <div class="logo">
                <h1>Money Manager</h1>
            </div>
            <ul class="nav-area">
                <!-- <li><a href="#">Home</a></li> -->
                <li><a href="expense.php">Add Expense</a></li>
                <li><a href="Details.php">Expense Details</a></li>
                <li><a href="index.php">Logout</a></li>
            </ul>
        </div>
        <div class="main">
            <div class="left">

            </div>
            <div class="right">

            </div>
            <!-- <p>hello everyon thisi is the website where you can </p> -->
        </div>
  </header>
    </div>
  

</body>
</html>